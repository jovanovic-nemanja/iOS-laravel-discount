package com.thatdubaigirl.com.Utils;

import com.thatdubaigirl.com.Model.Categori_Model;

import java.util.ArrayList;

public class Const {

    public static String review_type = "0";
    public static String image_type = "0";
    public static String review_type_a = "0";
    public static String Home_page = "0";
    public static String path_img = "";
    public static String catgeory_page = "0";
    public static ArrayList<Categori_Model> home_list;
    public static ArrayList<Categori_Model> Categori_Model;
    public static ArrayList<Categori_Model> product_list;


}
