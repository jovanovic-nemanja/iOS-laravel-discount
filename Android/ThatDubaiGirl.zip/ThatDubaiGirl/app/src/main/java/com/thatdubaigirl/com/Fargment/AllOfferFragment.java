package com.thatdubaigirl.com.Fargment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.thatdubaigirl.com.R;


public class AllOfferFragment extends Fragment {

    public AllOfferFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_all_offer, container, false);
        return v;
    }
}