//
//  FeaturedViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 20.12.20..
//

import UIKit

class FeaturedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var discounts: [Discount] = []
    @IBOutlet weak var tableView: UITableView!
    
    func updateTableView() {
        discounts.removeAll()
        for discount in DataManager.discounts {
            if (Int(discount.status!) == 2) {
                discounts.append(discount)
            }
        }
        
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        DataManager.loadDatas(self.view) {
            self.updateTableView()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.title = "Home"
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return discounts.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.width / 2 + 138
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiscountCell", for: indexPath) as! DiscountTableViewCell
        
        cell.viewCard.layer.cornerRadius = 8
        
        
        cell.ivVendor.layer.cornerRadius = cell.ivVendor.bounds.width / 2


        // Configure the cell...
        let discount = discounts[indexPath.row]
        cell.labelTitle.text = discount.title
        cell.labelDetail.text = discount.description
        cell.ivImage.sd_setImage(with: URL(string: APIManager.urlImage + discount.photo!), completed: nil)
        
        cell.ivVendor.sd_setImage(with: URL(string: APIManager.urlImage + discount.vendorPhoto!), completed: nil)
        
        cell.labelVendorName.text = discount.vendorName
        cell.labelCategoryName.text = discount.categoryName

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detail", sender: discounts[indexPath.row])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "detail") {
            let discount = sender as! Discount
            if let vcDetail = segue.destination as? DetailViewController {
                vcDetail.discount = discount
            }
        }
    }
}
