//
//  DiscountViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 19.12.20..
//

import UIKit
import HMSegmentedControl

class DiscountViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var discounts: [Discount] = []
    
    @IBOutlet weak var segmentedControl: HMSegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    func updateTableView() {
        if (DataManager.categoryID == 0) {
            discounts = DataManager.discounts
        } else if (DataManager.categoryID == -1) {
            discounts.removeAll()
            for discount in DataManager.discounts {
                if (Int(discount.status!) == 2) {
                    discounts.append(discount)
                }
            }
        } else {
            discounts.removeAll()
            for discount in DataManager.discounts {
                if (Int(discount.categoryId!) == DataManager.categoryID) {
                    discounts.append(discount)
                }
            }
        }
        
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.segmentedControl.sectionTitles = ["ALL"]
        self.segmentedControl.selectionStyle = .fullWidthStripe
        self.segmentedControl.selectionIndicatorLocation = .bottom
        self.segmentedControl.isVerticalDividerEnabled = true;
        self.segmentedControl.verticalDividerWidth = 0.5
        self.segmentedControl.verticalDividerColor = UIColor.black
        
        self.segmentedControl.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.segmentedControl.selectedTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.systemBlue]
        
        self.segmentedControl.addTarget(self, action: #selector(onChanged), for: .valueChanged)
        
        self.tableView.tableFooterView = UIView()

        for category in DataManager.categories {
            self.segmentedControl.sectionTitles?.append(category.name)
        }

        self.updateTableView()
    }
    
    @objc func onChanged() {
        if (self.segmentedControl.selectedSegmentIndex == 0) {
            DataManager.categoryID = 0
        } else {
            let selectedCategory = DataManager.categories[Int(self.segmentedControl.selectedSegmentIndex) - 1]
            DataManager.categoryID = selectedCategory.id
        }

        updateTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.tabBarController?.title = "Category"
        
        if (DataManager.categoryID == 0) {
            self.segmentedControl.selectedSegmentIndex = 0
        } else {
            for i in 0..<DataManager.categories.count {
                if (DataManager.categories[i].id == DataManager.categoryID) {
                    self.segmentedControl.selectedSegmentIndex = UInt(i + 1)
                }
            }
        }
        
        updateTableView()
    }

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return discounts.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.width / 2 + 138
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiscountCell", for: indexPath) as! DiscountTableViewCell
        
        cell.viewCard.layer.cornerRadius = 8
        
        
        cell.ivVendor.layer.cornerRadius = cell.ivVendor.bounds.width / 2


        // Configure the cell...
        let discount = discounts[indexPath.row]
        cell.labelTitle.text = discount.title
        cell.labelDetail.text = discount.description
        cell.ivImage.sd_setImage(with: URL(string: APIManager.urlImage + discount.photo!), completed: nil)
        
        cell.ivVendor.sd_setImage(with: URL(string: APIManager.urlImage + discount.vendorPhoto!), completed: nil)
        
        cell.labelVendorName.text = discount.vendorName
        cell.labelCategoryName.text = discount.categoryName

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detail", sender: discounts[indexPath.row])
    }

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "detail") {
            let discount = sender as! Discount
            if let vcDetail = segue.destination as? DetailViewController {
                vcDetail.discount = discount
            }
        }
    }
}
