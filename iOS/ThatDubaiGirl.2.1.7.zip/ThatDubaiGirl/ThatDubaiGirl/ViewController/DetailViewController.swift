//
//  DetailViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import UIKit
import SDWebImage

class DetailViewController: UIViewController {
    
    public var discount: Discount?
    
    @IBOutlet weak var ivDiscount: UIImageView!
    @IBOutlet weak var labelDiscountTitle: UILabel!
    @IBOutlet weak var labelDiscountDetail: UILabel!
    
    @IBOutlet weak var viewVendor: UIView!
    @IBOutlet weak var ivVendor: UIImageView!
    @IBOutlet weak var labelVendorName: UILabel!
    @IBOutlet weak var labelVendorLocation: UILabel!
//    @IBOutlet weak var labelVendorPhone: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ivVendor.clipsToBounds = true
        ivVendor.layer.masksToBounds = true
        ivVendor.layer.cornerRadius = ivVendor.bounds.width / 2
        ivVendor.layer.borderWidth = 0.5
        ivVendor.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor
        
        ivDiscount.sd_setImage(with: URL(string: APIManager.urlImage + (discount?.photo)!), completed: nil)
        labelDiscountTitle.text = discount?.title
        labelDiscountDetail.text = discount?.description
        
        ivVendor.sd_setImage(with: URL(string: APIManager.urlImage + (discount?.vendorPhoto)!), completed: nil)
        labelVendorName.text = discount?.vendorName
        labelVendorLocation.text = discount?.location
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onGenerate(_ sender: Any) {
        self.performSegue(withIdentifier: "id", sender: discount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "id") {
            let discount = sender as! Discount
            if let vcID = segue.destination as? IDViewController {
                vcID.discount = discount
            }
        }
    }
}
