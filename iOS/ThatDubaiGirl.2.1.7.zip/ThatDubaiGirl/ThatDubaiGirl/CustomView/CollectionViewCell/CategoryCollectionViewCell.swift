//
//  CategoryCollectionViewCell.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 18.12.20..
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ivCategory: UIImageView!
    @IBOutlet weak var labelCategoryName: UILabel!
}
