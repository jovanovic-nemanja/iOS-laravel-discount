//
//  DiscountTableViewCell.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 8.12.20..
//

import UIKit

class DiscountTableViewCell: UITableViewCell {

    @IBOutlet weak var viewCard: UIView!
    
    @IBOutlet weak var ivImage: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDetail: UILabel!
    
    @IBOutlet weak var ivVendor: UIImageView!
    @IBOutlet weak var labelVendorName: UILabel!
    @IBOutlet weak var labelCategoryName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
