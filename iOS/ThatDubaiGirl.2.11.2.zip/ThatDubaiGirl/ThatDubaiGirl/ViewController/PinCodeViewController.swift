//
//  PinCodeViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7/12/21.
//

import UIKit

protocol PinCodeViewControllerDelegate: class {
    func updateDetail()
}

class PinCodeViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var pinCodeField: UITextField!
    
    public var discount: Discount!
    
    weak var delegate: PinCodeViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        pinCodeField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        if let text = pinCodeField.text {
            self.navigationItem.rightBarButtonItem?.isEnabled = (text.count == 4)
        }
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "id") {
            let discount = sender as! Discount
            if let vcID = segue.destination as? IDViewController {
                vcID.discount = discount
            }
        }
    }
    
    @IBAction func onSkip(_ sender: Any) {
        performSegue(withIdentifier: "id", sender: discount)
    }
    
    @IBAction func onSubmit(_ sender: Any) {
        guard let pinCode = pinCodeField.text, !pinCode.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "Error", message: "Please input PIN code.")
            return
        }
        
        let id = Int(discount.id!)!
        let userID = DataManager.currentUser?.id
        let code = Int(pinCode)!
        
        UIManager.shared.showHUD(view: self.view)
        APIManager.shared.validatePinCode(id, userID: userID!, code: code, { (success, message) in
            UIManager.shared.hideHUD()
            if (success) {
                if (self.delegate != nil) {
                    self.delegate?.updateDetail()
                }

                self.performSegue(withIdentifier: "id", sender: self.discount)
            } else {
                UIManager.shared.showAlert(vc: self, title: "Failed", message: message!)
            }
        })
    }
    
    // MARK: TextFieldDelegate
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentCharacterCount = textField.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= 4
    }
}
