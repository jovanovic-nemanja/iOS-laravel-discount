//
//  DataManager.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import UIKit
import Foundation

class DataManager {
    static let shared = DataManager()
    
    public static var categoryID = 0
    public static var appColor = UIColor(red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0)
    
    public static var currentUser: User?
}
