//
//  VerifyViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 20.11.20..
//

import UIKit

class VerifyViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var verifyButton: UIButton!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var popupTopConstraints: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func setupUI() {
        
        self.navigationController?.navigationBar.isHidden = true
        
        verifyButton.layer.borderWidth = 1
        verifyButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        verifyButton.layer.masksToBounds = true
        verifyButton.layer.cornerRadius = 8.0
        
        okButton.layer.borderWidth = 1
        okButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        okButton.layer.masksToBounds = true
        okButton.layer.cornerRadius = 8.0
        
    }
    
    @IBAction func onVerifyButton(_ sender: Any) {
        
        guard let email = emailTextField.text, !email.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input email address")
            return
        }
        
        UIManager.shared.showHUD(view: self.view)

        ThatdubaigirlAPI.shared.emailVerify(email) { (success, msg) in

            UIManager.shared.hideHUD()

            if success {

//                UIManager.shared.showAlert(vc: self, title: "", message: msg!) { (alert) in
//                    let alertController = UIAlertController(title: "", message: "Verify Code", preferredStyle: .alert)
//                    let okAction = UIAlertAction(title: "OK", style: .default) { (alert) in
//
//                        let codeString =  alertController.textFields![0].text
//                        let code = Int(codeString!)
//                        UIManager.shared.showHUD(view: self.view)
//                        ThatdubaigirlAPI.shared.validateCode(email, code: code!) { (success, msg) in
//                            UIManager.shared.hideHUD()
//
//                            if success {
//
//                                UIManager.shared.showAlert(vc: self, title: "", message: msg!) { (alert) in
//                                    let signupVC = UIStoryboard(name: "Login", bundle: nil).instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
//                                    signupVC.emailString = email
//                                    self.navigationController?.pushViewController(signupVC, animated: true)
//                                }
//
//                            } else {
//                                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
//                            }
//                        }
//
//                    }
//                    alertController.addTextField(configurationHandler: {(textField: UITextField) in
//                        textField.autocorrectionType = .default
//                        textField.placeholder = "Verify code"
//                    })
//                    alertController.addAction(okAction)
//                    self.present(alertController, animated: true, completion: nil)
//                }
                
                UIView.animate(withDuration: 0.6) {

                    self.popupTopConstraints.constant = -1 * (self.view.bounds.height - 40)
                    
                }

            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }

        }
        
        
        
    }
    
    @IBAction func onBackButton(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func onDismissPopup(_ sender: Any) {
        UIView.animate(withDuration: 0.6) {
            self.popupTopConstraints.constant = 0
        }
    }
    
    @IBAction func onValidate(_ sender: Any) {
        let email = self.emailTextField.text
        let codeString =  self.codeTextField.text
        let code = Int(codeString!)
        UIManager.shared.showHUD(view: self.view)
        ThatdubaigirlAPI.shared.validateCode(email!, code: code!) { (success, msg) in
            UIManager.shared.hideHUD()

            if success {

                let signupVC = UIStoryboard(name: "Login", bundle: nil).instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
                signupVC.emailString = email
                self.navigationController?.pushViewController(signupVC, animated: true)
                
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
        }
    }
    

}
