//
//  DiscountsViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 22.11.20..
//

import UIKit
import SDWebImage

class DiscountsViewController: UIViewController {

    @IBOutlet weak var discountsTable: UITableView!
    
    private var discounts: [Discount] = []
    public var vendorId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        discountsTable.register(UINib(nibName: "DiscountTableViewCell", bundle: nil), forCellReuseIdentifier: "DiscountTableViewCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = true
        
        UIManager.shared.showHUD(view: self.view)
        ThatdubaigirlAPI.shared.getDiscounts(vendorId!) { (success, discounts, msg) in
            UIManager.shared.hideHUD()
            if success {
                self.discounts = discounts!
                self.discountsTable.reloadData()
            } else {
                self.view.makeToast(message: msg!)
            }
        }
        
    }
    
    @IBAction func onBack(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension DiscountsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return discounts.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiscountTableViewCell", for: indexPath) as! DiscountTableViewCell
        let discount = discounts[indexPath.row]
        cell.titleLabel.text = discount.title
        cell.detailsLabel.text = discount.description
        cell.discountImageView.clipsToBounds = true
        cell.discountImageView.layer.masksToBounds = true
        cell.discountImageView.layer.cornerRadius = cell.discountImageView.bounds.width / 2
        cell.discountImageView.sd_setImage(with: URL(string: String(format: "%@%@", ThatdubaigirlAPI.mainImageURL, discount.photoURL!)), completed: nil)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let discount = discounts[indexPath.row]
        let detailsVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "DetailsViewController") as DetailsViewController
        detailsVC.discount = discount
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
}
