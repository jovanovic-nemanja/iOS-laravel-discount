//
//  SignUpViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 20.11.20..
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfBirthday: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfConfirmPassword: UITextField!
    
    public var emailString: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Presets email address
        tfEmail.text = emailString
        
        //Sets Signup button style
        setupUI()
        
        //Sets date picker for birthday
        tfBirthday.setInputViewDatePicker(target: self, selector: #selector(tapDone))
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func setupUI() {
        
        signupButton.layer.borderWidth = 1
        signupButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        signupButton.layer.masksToBounds = true
        signupButton.layer.cornerRadius = 8.0
        
    }
    
    @objc func tapDone() {
        if let datePicker = self.tfBirthday.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.dateStyle = .medium
            self.tfBirthday.text = dateformatter.string(from: datePicker.date)
        }
        self.tfBirthday.resignFirstResponder()
    }
    
    @IBAction func onSignup(_ sender: Any) {
        
        
        guard let username = tfName.text, !username.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input name")
            return
        }
        guard let email = tfEmail.text, !email.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input email address")
            return
        }
        guard let address = tfAddress.text, !address.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input address")
            return
        }
        guard let birthday = tfBirthday.text, !birthday.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input birthday")
            return
        }
        guard let password = tfPassword.text, !password.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
            return
        }
        guard let password_confirmation = tfConfirmPassword.text, !password_confirmation.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
            return
        }
        
        UIManager.shared.showHUD(view: self.view)
        
        ThatdubaigirlAPI.shared.register(email, username: username, birthday: birthday, address: address, password: password, password_confirmation: password_confirmation) { (success, user, msg) in
            
            UIManager.shared.hideHUD()
            
            if success {
                
                UserDefaults.standard.setValue(user?.email, forKey: "email")
                let homeVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "HomeViewController") as HomeViewController
                self.navigationController?.pushViewController(homeVC, animated: true)
                
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
            
            
        }
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UITextField {
    
    func setInputViewDatePicker(target: Any, selector: Selector) {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        datePicker.datePickerMode = .date
        self.inputView = datePicker
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancel, flexible, barButton], animated: false)
        self.inputAccessoryView = toolBar
    }
    
    @objc func tapCancel() {
        self.resignFirstResponder()
    }
    
}
