//
//  LoginViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 19.11.20..
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Sets button & textfield style
        setupUI()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = true
        
    }
    
    func setupUI() {
        
        //Login Button
        loginButton.layer.borderWidth = 1
        loginButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        loginButton.layer.masksToBounds = true
        loginButton.layer.cornerRadius = 8.0
        
        //Signup Button
        signupButton.layer.borderWidth = 1
        signupButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        signupButton.layer.masksToBounds = true
        signupButton.layer.cornerRadius = 8.0
        
    }

    @IBAction func onLogin(_ sender: Any) {
        
        guard let email = emailTextField.text, !email.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input email address")
            return
        }
        guard let password = passwordTextField.text, !password.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
            return
        }
        
        UIManager.shared.showHUD(view: self.view)
        
        ThatdubaigirlAPI.shared.login(email, password: password) { (success, user, msg) in
            
            UIManager.shared.hideHUD()
            
            if success {                
                UserDefaults.standard.setValue(user?.email, forKey: "email")
                let homeVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "HomeViewController") as HomeViewController
                self.navigationController?.pushViewController(homeVC, animated: true)
                
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
            
        }
        
    }
}

