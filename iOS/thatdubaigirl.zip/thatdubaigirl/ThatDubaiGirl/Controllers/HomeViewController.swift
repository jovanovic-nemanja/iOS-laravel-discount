//
//  HomeViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 21.11.20..
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var categoryTable: UITableView!
    @IBOutlet weak var navTitleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    
    private var categories: [Category]? = []
    private var vendors: [Vendor]?
    
    enum TableModel {
        case category
        case vendor
    }

    var tableModel: TableModel = .category
    
    override func viewDidLoad() {
        super.viewDidLoad()

        categoryTable.register(UINib(nibName: "CategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "CategoryTableViewCell")
        
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = true
        
        switch tableModel {
        case .category:
            navTitleLabel.text = "Categories"
            backButton.isHidden = true
        case .vendor:
            navTitleLabel.text = "Vendors"
            backButton.isHidden = false
        }
        
        UIManager.shared.showHUD(view: self.view)
        ThatdubaigirlAPI.shared.getCategories { (success, categories, msg) in
            UIManager.shared.hideHUD()
            if success {
                self.categories = categories
                self.categoryTable.reloadData()
            } else {
                self.view.makeToast(message: msg!)
            }
        }
        
        
    }
    
    @IBAction func onBack(_ sender: Any) {
        
        tableModel = .category
        navTitleLabel.text = "Categories"
        backButton.isHidden = true
        categoryTable.reloadData()
    }
    
    @IBAction func onLogout(_ sender: Any) {
        
        
        
    }
    

}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch tableModel {
        case .category:
            return categories!.count
        case .vendor:
            return vendors!.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell", for: indexPath) as! CategoryTableViewCell
        switch tableModel {
        case .category:
            let category = categories![indexPath.row]
            cell.categoryLabel.text = category.name
        case .vendor:
            let vendor = vendors![indexPath.row]
            cell.categoryLabel.text = vendor.name
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch tableModel {
        case .category:
            
            let category = categories![indexPath.row]
            let categoryId = category.id
            UIManager.shared.showHUD(view: self.view)
            ThatdubaigirlAPI.shared.getVendors(categoryId!, { [self] (success, vendors, msg) in
                UIManager.shared.hideHUD()
                if success {
                    self.vendors = vendors
                    tableModel = .vendor
                    self.navTitleLabel.text = "Vendors"
                    self.backButton.isHidden = false
                    self.categoryTable.reloadData()
                } else {
                    self.view.makeToast(message: msg!)
                }
            })
            
            
        case .vendor:
            let vendor = vendors![indexPath.row]
            let discountsVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "DiscountsViewController") as DiscountsViewController
            discountsVC.vendorId = vendor.id
            self.navigationController?.pushViewController(discountsVC, animated: true)
        }
        
        
    }
    
    
}
