//
//  Endpoint.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 23.11.20..
//

import Foundation

enum Endpoint: String {
    case login = "loginUser"
    case register = "register"
    case emailVerify = "emailverify"
    case validateCode = "validateCode"
    case vendors = "vendros"
    case categories = "categories"
    case discounts = "getdiscountlistsbyvendor"
}
