//
//  ThatdubaigirlAPI.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 21.11.20..
//

import Foundation
import Alamofire
import ObjectMapper


class ThatdubaigirlAPI {
    
    static let shared = ThatdubaigirlAPI()
    let mainURL = "https://tdguae.com/api/v1/"
    public static let mainImageURL = "https://tdguae.com/uploads/"
    
    func login(_ email: String, password: String, _ callback: @escaping (Bool, User?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.login.rawValue
        let params = [
            "email": email,
            "password": password
        ]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [String: Any] {
                            guard let user = Mapper<User>().map(JSON: data) else {
                                callback(false, nil, "No objects found")
                                return
                            }
                            callback(true, user, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func emailVerify(_ email: String, _ callback: @escaping (Bool, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.emailVerify.rawValue
        let params = [
            "email": email
        ]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, msg)
                    } else {
                        callback(true, msg)
                    }
                }
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func validateCode(_ email: String, code: Int, _ callback: @escaping (Bool, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.validateCode.rawValue
        let params = [
            "email": email,
            "code": code
        ] as [String : Any]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, msg)
                    } else {
                        callback(true, msg)
                    }
                }
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func register(_ email: String, username: String, birthday: String, address: String, password: String, password_confirmation: String, _ callback: @escaping (Bool, User?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.register.rawValue
        let params = [
            "email": email,
            "username": username,
            "birthday": birthday,
            "address": address,
            "password": password,
            "password_confirmation": password_confirmation
        ]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [String: Any] {
                            guard let user = Mapper<User>().map(JSON: data) else {
                                callback(false, nil, "No objects found")
                                return
                            }
                            callback(true, user, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func getCategories(_ callback: @escaping (Bool, [Category]?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.categories.rawValue
                
        AF.request(urlString, method: .get, parameters: nil, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [[String: Any]] {
                            let objects = Mapper<Category>().mapArray(JSONArray: data)
                            callback(true, objects, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func getVendors(_ categoryId: Int, _ callback: @escaping (Bool, [Vendor]?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.vendors.rawValue
        let params = [
            "category_id": categoryId
        ]
                
        AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [[String: Any]] {
                            let objects = Mapper<Vendor>().mapArray(JSONArray: data)
                            callback(true, objects, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func getDiscounts(_ vendorId: String, _ callback: @escaping (Bool, [Discount]?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.discounts.rawValue
        let params = [
            "vendor_id": vendorId
        ]
                
        AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [[String: Any]] {
                            let objects = Mapper<Discount>().mapArray(JSONArray: data)
                            callback(true, objects, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    
}

