//
//  Category.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 24.11.20..
//

import Foundation
import ObjectMapper

struct Category: Mappable {
    var id: Int?
    var name: String?
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        name <- map["category_name"]
    }
    
}
