//
//  Discount.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 24.11.20..
//

import Foundation
import ObjectMapper

struct Discount: Mappable {
    var id: Int?
    var title: String?
    var description: String?
    var vendorName: String?
    var phoneNumber: String?
    var location: String?
    var photoURL: String?
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        title <- map["title"]
        description <- map["description"]
        vendorName <- map["vendorname"]
        phoneNumber <- map["phone"]
        location <- map["location"]
        photoURL <- map["photo"]
        
        if description!.count > 0 {
            description = description!.replacingOccurrences(of: "\r", with: " ")
            description = description!.replacingOccurrences(of: "\n", with: " ")
        }
        
    }
    
}
