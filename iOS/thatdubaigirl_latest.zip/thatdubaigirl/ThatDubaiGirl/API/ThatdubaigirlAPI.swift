//
//  ThatdubaigirlAPI.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 21.11.20..
//

import Foundation
import Alamofire
import ObjectMapper


class ThatdubaigirlAPI {
    
    static let shared = ThatdubaigirlAPI()
    let mainURL = "https://tdguae.com/api/v1/"
    public static let mainImageURL = "https://tdguae.com/uploads/"
    
    func login(_ email: String, password: String, _ callback: @escaping (Bool, User?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.login.rawValue
        let params = [
            "email": email,
            "password": password
        ]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [String: Any] {
                            guard let user = Mapper<User>().map(JSON: data) else {
                                callback(false, nil, "No objects found")
                                return
                            }
                            callback(true, user, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func emailVerify(_ email: String, _ callback: @escaping (Bool, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.emailVerify.rawValue
        let params = [
            "email": email
        ]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, msg)
                    } else {
                        callback(true, msg)
                    }
                }
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func validateCode(_ email: String, code: Int, _ callback: @escaping (Bool, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.validateCode.rawValue
        let params = [
            "email": email,
            "code": code
        ] as [String : Any]
                
        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, msg)
                    } else {
                        callback(true, msg)
                    }
                }
                
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func register(_ email: String, username: String, birthday: String, address: String, password: String, password_confirmation: String,image:UIImage, _ callback: @escaping (Bool, User?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.register.rawValue
        let params = [
            "email": email,
            "username": username,
            "birthday": birthday,
            "address": address,
            "password": password,
            "password_confirmation": password_confirmation
        ]
        
        let url = URL(string: urlString)
        let imageData = image.jpegData(compressionQuality: 0.8)
        
        AF.upload(multipartFormData: { multipartFormData in
            
            for (key, value) in params {
                multipartFormData.append(value.data(using: .utf8)!, withName: key)
            }
            
            if let data = imageData{
                multipartFormData.append(data, withName: "photo", fileName: "\(Date.init().timeIntervalSince1970).png", mimeType: "image/png")
            }
        },
        to: url!, method: .post , headers: nil)
        .responseJSON(completionHandler: { (response) in
            
            print("response is",response)
            
            if let err = response.error{
                print(err)
                callback(false, nil, "failed")
                
            }
            print("Succesfully uploaded")
            
            if let jsonObject = response.value as? [String:Any]{
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [String: Any] {
                            guard let user = Mapper<User>().map(JSON: data) else {
                                callback(false, nil, "No objects found")
                                return
                            }
                            callback(true, user, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                    }
                    
                }
            }
        })
    }
    
   
    
    func getVendors(_ categoryId: Int, _ callback: @escaping (Bool, [Vendor]?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.vendors.rawValue
        let params = [
            "category_id": categoryId
        ]
                
        AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [[String: Any]] {
                            let objects = Mapper<Vendor>().mapArray(JSONArray: data)
                            callback(true, objects, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func getDiscounts(_ vendorId: String, _ callback: @escaping (Bool, [Discount]?, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.discounts.rawValue
        let params = [
            "vendor_id": vendorId
        ]
                
        AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let msg = jsonObject["msg"] as? String
                    if status == "failed" {
                        callback(false, nil, msg)
                    } else {
                        if let data = jsonObject["data"] as? [[String: Any]] {
                            let objects = Mapper<Discount>().mapArray(JSONArray: data)
                            callback(true, objects, msg)
                        } else {
                            callback(false, nil, msg)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
    func getCategories(_ callback: @escaping (Bool, [Category]?, String?) -> Void) {
            
            let urlString = mainURL + Endpoint.categories.rawValue
                    
            AF.request(urlString, method: .get, parameters: nil, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
                do {
                    guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                        print("Error: Cannot convert data to JSON object")
                        return
                    }
                    if let status = jsonObject["status"] as? String {
                        let msg = jsonObject["msg"] as? String
                        if status == "failed" {
                            callback(false, nil, msg)
                        } else {
                            if let data = jsonObject["data"] as? [[String: Any]] {
                                let objects = Mapper<Category>().mapArray(JSONArray: data)
                                callback(true, objects, msg)
                            } else {
                                callback(false, nil, msg)
                            }
                            
                        }
                    }
                } catch {
                    print("Error: Trying to convert JSON data to string")
                    return
                }
            }
            
        }
    
    func getDiscounts(_ category: Category?, _ callback: @escaping (Bool, [Discount]?, String?) -> Void) {
            
            var urlString = mainURL + Endpoint.getDiscountlists.rawValue
            
            var params = [String:Any]()
            if let fCategory = category {
               //params["vendor_id"] = fVenderID
                urlString = mainURL + Endpoint.getDiscountlists.rawValue
                params["category_id"] = fCategory.id
                //params["vendor_name"] = fCategory.name
                //+ "?category_id=\(fCategory.id)&vendor_name=\(fCategory.name)"//Endpoint.discounts.rawValue
            }
            
                    
            AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
                do {
                    guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                        print("Error: Cannot convert data to JSON object")
                        return
                    }
                    if let status = jsonObject["status"] as? String {
                        let msg = jsonObject["msg"] as? String
                        if status == "failed" {
                            callback(false, nil, msg)
                        } else {
                            if let data = jsonObject["data"] as? [[String: Any]] {
                                let objects = Mapper<Discount>().mapArray(JSONArray: data)
                                callback(true, objects, msg)
                            } else {
                                callback(false, nil, msg)
                            }
                            
                        }
                    }
                } catch {
                    print("Error: Trying to convert JSON data to string")
                    return
                }
            }
        }
    
    
    func getDiscountsSearch(_ strToSrearch: String,_ category: Category?, _ callback: @escaping (Bool, [Discount]?, String?) -> Void) {
        
        //https://tdguae.com/api/v1/getDiscountlists?category_id=2&vendor_name=w
        
       var params = [String:Any]()
        params["vendor_name"] = strToSrearch
        var urlString = mainURL + Endpoint.getDiscountlists.rawValue

        if let fCategory = category {
            urlString = mainURL + Endpoint.getDiscountlists.rawValue
                //+ "?category_id=\(fCategory.id)&vendor_name=\(strToSrearch)"//Endpoint.discounts.rawValue
            params["category_id"] = fCategory.id
           
            
        }
        
         //  let urlString = mainURL + Endpoint.getDiscountlists.rawValue + "?vendor_name=\(strToSrearch)"//Endpoint.discounts.rawValue
        let request = AF.request(urlString, method: .get, parameters: params, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
               do {
                   guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                       print("Error: Cannot convert data to JSON object")
                       return
                   }
                   if let status = jsonObject["status"] as? String {
                       let msg = jsonObject["msg"] as? String
                       if status == "failed" {
                           callback(false, nil, msg)
                       } else {
                           if let data = jsonObject["data"] as? [[String: Any]] {
                               let objects = Mapper<Discount>().mapArray(JSONArray: data)
                               callback(true, objects, msg)
                           } else {
                               callback(false, nil, msg)
                           }
                           
                       }
                   }
               } catch {
                   print("Error: Trying to convert JSON data to string")
                   return
               }
           }
        print(request.description)
       }
    
    // get video link
    
    func getVideo(_ callback: @escaping (Bool, String?) -> Void) {
        
        let urlString = mainURL + Endpoint.getvideolink.rawValue
                
        AF.request(urlString, method: .get, parameters: nil, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                if let status = jsonObject["status"] as? String {
                    let datas = jsonObject["data"] as? String
                    if status == "failed" {
                        callback(false , datas)
                    } else {
                        if let data = jsonObject["data"] as? String {
                           // let objects = Mapper<video>()
                            callback(true , data)
                        } else {
                            callback(false , datas)
                        }
                        
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
        
    }
    
}

