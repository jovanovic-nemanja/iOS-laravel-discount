//
//  video.swift
//  ThatDubaiGirl
//
//  Created by Murteza on 03/12/2020.
//

import Foundation
import Foundation
import ObjectMapper

struct video: Mappable {
    var status: String?
    var data: String?
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        status <- map["status"]
        data <- map["data"]
    }
    
}


