//
//  User.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 23.11.20..
//

import Foundation
import ObjectMapper

struct User: Mappable {
    
    var email: String?
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        email <- map["email"]
    }
    
    
    
}
