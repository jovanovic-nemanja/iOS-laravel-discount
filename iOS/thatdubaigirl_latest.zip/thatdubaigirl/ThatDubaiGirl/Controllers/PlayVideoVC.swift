//
//  PlayVideoVC.swift
//  ThatDubaiGirl
//
//  Created by Murteza on 03/12/2020.
//

import UIKit
import WebKit
import AVKit



class PlayVideoVC: UIViewController {
    @IBOutlet weak var imgView: UIImageView!
    
    var player: AVPlayer?
    var playerItem: AVPlayerItem?
    var playerLayer  = AVPlayerLayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getVideLink()
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    
    func playGlobalVideo(url :String) {
        
        if let url = URL(string: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") {
            //2. Create AVPlayer object
            let asset = AVAsset(url: url)
            let playerItem = AVPlayerItem(asset: asset)
            let player = AVPlayer(playerItem: playerItem)
            
            //3. Create AVPlayerLayer object
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.imgView.bounds //bounds of the view in which AVPlayer should be displayed
            playerLayer.videoGravity = .resizeAspect
            
            //4. Add playerLayer to view's layer
            self.imgView.layer.addSublayer(playerLayer)
            
            //5. Play Video
            player.play()
        }
    }
    
    
    

    @IBAction private func skipAction(_ sender: UIButton){
        if let scen = self.view.window?.windowScene?.delegate as? SceneDelegate {
                    scen.showMain()
                }
    }
    

    func getVideLink(){
        UIManager.shared.showHUD(view: self.view)
        ThatdubaigirlAPI.shared.getVideo({ (success, data) in
            UIManager.shared.hideHUD()
            if success {
                print("videl url is ... \(data)")
                //self.PlayVideo(url: data ?? "")
                self.playGlobalVideo(url: data ?? "")
            } else {
                self.view.makeToast(message: "Can get Video Link")
            }
        })
     }
    
}
