//
//  SignUpViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 20.11.20..
//

import UIKit
import Photos

class SignUpViewController: UIViewController {

    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfBirthday: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfConfirmPassword: UITextField!
    @IBOutlet weak var ivProfileImage: UIImageView!
    
    public var emailString: String!
    var isPhotoSelected : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Presets email address
        tfEmail.text = emailString
        
        //Sets Signup button style
        setupUI()
        
        //Sets date picker for birthday
        tfBirthday.setInputViewDatePicker(target: self, selector: #selector(tapDone))
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func setupUI() {
        
        signupButton.layer.borderWidth = 1
        signupButton.layer.borderColor = UIColor(displayP3Red: 244/255, green: 149/255, blue: 123/255, alpha: 1.0).cgColor
        signupButton.layer.masksToBounds = true
        signupButton.layer.cornerRadius = 8.0
        
        self.ivProfileImage.image = UIImage(named: "profile")
        self.ivProfileImage.contentMode = .scaleAspectFill
        self.ivProfileImage.layer.cornerRadius = self.ivProfileImage.frame.size.width/2
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        ivProfileImage.isUserInteractionEnabled = true
        ivProfileImage.addGestureRecognizer(tapGestureRecognizer)
        
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        self.getImageData()
    }
    
    func getImageData(){
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
     
        let camera = UIAlertAction(title: "Camera", style: .default) { action in
            self.openImagePicker(sourceType: UIImagePickerController.SourceType.camera)
        }
        alertController.addAction(camera)
        
        let photoGallery = UIAlertAction(title: "Photo Gallery", style: .default) { action in
            self.openImagePicker(sourceType: UIImagePickerController.SourceType.photoLibrary)
        }
        alertController.addAction(photoGallery)
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { action in

        }
        alertController.addAction(cancel)
        self.present(alertController, animated: true)
    }

    func openImagePicker(sourceType: UIImagePickerController.SourceType){

        
        isPhotoPermissionAuthorized(objViewController: self) { (isAuthorized) in
            if isAuthorized {
                DispatchQueue.main.async {
                    let objImagePicker = UIImagePickerController()
                    UINavigationBar.appearance().tintColor = UIColor.white
                    objImagePicker.allowsEditing = true
                    objImagePicker.delegate = self
                    objImagePicker.sourceType =  sourceType//.photoLibrary
                    objImagePicker.mediaTypes = ["public.image"] //,String(kUTTypeVideo),String(kUTTypeMPEG4)
                    objImagePicker.videoQuality = .typeIFrame960x540//.typeIFrame1280x720 //iFrame960x540
                    self.navigationController?.present(objImagePicker, animated: true, completion: nil)
                }
               
            }
        }
    }
    
    
    func isPhotoPermissionAuthorized(objViewController: UIViewController, completion:@escaping ((Bool) -> Void)) {

        let status = PHPhotoLibrary.authorizationStatus()

        switch status {

        case .authorized:
            completion(true)
            break

        case .notDetermined:

            PHPhotoLibrary.requestAuthorization({ (newStatus) in
                if newStatus == PHAuthorizationStatus.authorized {
                    completion(true)
                } else {
                    completion(false)
                }
            })

            break

        case .denied:

            let strMessage: String = "Please Allow Access to your Photos"
            let alertController = UIAlertController(title: "ThatDubaiGirl", message: strMessage, preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: "Ok", style: .default) { action in
                self.dismiss(animated: true, completion: nil)
            }
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true)
            break

        case .restricted:
            completion(false)
            break
        default:
            completion(false)
            break
        }
    }
    
    @objc func tapDone() {
        if let datePicker = self.tfBirthday.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.dateStyle = .medium
            self.tfBirthday.text = dateformatter.string(from: datePicker.date)
        }
        self.tfBirthday.resignFirstResponder()
    }
    
    @IBAction func onSignup(_ sender: Any) {
        
        
        guard let username = tfName.text, !username.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input name")
            return
        }
        guard let email = tfEmail.text, !email.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input email address")
            return
        }
        guard let address = tfAddress.text, !address.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input address")
            return
        }
        guard let birthday = tfBirthday.text, !birthday.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input birthday")
            return
        }
        guard let password = tfPassword.text, !password.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
            return
        }
        guard let password_confirmation = tfConfirmPassword.text, !password_confirmation.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "", message: "Please input password")
            return
        }
        
        if !isPhotoSelected{
            UIManager.shared.showAlert(vc: self, title: "", message: "Please select profile picture")
            return
        }
        
        UIManager.shared.showHUD(view: self.view)
        
        ThatdubaigirlAPI.shared.register(email, username: username, birthday: birthday, address: address, password: password, password_confirmation: password_confirmation,image: self.ivProfileImage.image!) { (success, user, msg) in
            
            UIManager.shared.hideHUD()
            
            if success {
                
                UserDefaults.standard.setValue(user?.email, forKey: "email")
                if let sceneDelegate = self.view.window?.windowScene?.delegate as? SceneDelegate {
                    sceneDelegate.showVideo()
                }
                
//                let homeVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "HomeViewController") as HomeViewController
//                self.navigationController?.pushViewController(homeVC, animated: true)
                
            } else {
                UIManager.shared.showAlert(vc: self, title: "", message: msg!)
            }
            
            
        }
        
        
    }
    
    @IBAction func btnBackClick(_ sender: Any) {
        if let rootVC = UIStoryboard(name: "Login", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController{
           self.navigationController?.pushViewController(rootVC, animated: true)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UITextField {
    
    func setInputViewDatePicker(target: Any, selector: Selector) {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        datePicker.datePickerMode = .date
        self.inputView = datePicker
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)
        toolBar.setItems([cancel, flexible, barButton], animated: false)
        self.inputAccessoryView = toolBar
    }
    
    @objc func tapCancel() {
        self.resignFirstResponder()
    }
    
}

extension SignUpViewController : UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // Local variable inserted by Swift 4.2 migrator.
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        var newImage: UIImage
        if let possibleImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            self.ivProfileImage.image = possibleImage
            isPhotoSelected = true
           // self.uploadImageToServer(image: newImage)
        } else if let possibleImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            self.ivProfileImage.image = possibleImage
            isPhotoSelected = true
           // self.uploadImageToServer(image: newImage)
        } else {
            isPhotoSelected = false
            return
        }

        picker.dismiss(animated: true)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        isPhotoSelected = false
        picker.dismiss(animated: true, completion: nil)
    }
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }
}
