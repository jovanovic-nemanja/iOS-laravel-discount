//
//  WebViewController.swift
//  ThatDubaiGirl
//
//  Created by Dipak panchasara on 05/12/20.
//

import UIKit
import WebKit


class WebViewController: UIViewController {

    var pageType: ePageType = .facebook
    
    @IBOutlet var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadData()
    }
    
    func loadData(){
        
        var  link = URL(string:"https://www.facebook.com/")!
        
        if pageType == .youTube {
            link = URL(string:"https://www.youtube.com/")!
        }
        let request = URLRequest(url: link)
        webView.load(request)
    }

    @IBAction func onBackButton(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }

}
