//
//  DetailsViewController.swift
//  ThatDubaiGirl
//
//  Created by DevMober on 22.11.20..
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var discountImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var vendorNameLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    public var discount: Discount?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        discountImageView.clipsToBounds = true
        discountImageView.layer.masksToBounds = true
        discountImageView.layer.cornerRadius = discountImageView.bounds.width / 2
        loadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func loadData() {
        
        discountImageView.sd_setImage(with: URL(string: String(format: "%@%@", ThatdubaigirlAPI.mainImageURL, discount!.photoURL!)), completed: nil)
        titleLabel.text = discount!.title
        descLabel.text = discount!.description
        vendorNameLabel.text = discount!.vendorName
        locationLabel.text = discount!.location
        phoneLabel.text = discount!.phoneNumber
        
    }
    
    @IBAction func onBack(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func onLogout(_ sender: Any) {
        if let sceneDelegate = self.view.window?.windowScene?.delegate as? SceneDelegate {
            sceneDelegate.showLogin()
        }
    }
   

}
