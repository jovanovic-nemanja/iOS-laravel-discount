//
//  AppSideMenu.swift
//  ThatDubaiGirl
//
//  Created by Dipak panchasara on 05/12/20.
//

import Foundation
import UIKit
import FAPanels

class AppSideMenu: FAPanelController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
